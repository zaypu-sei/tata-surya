const canvas = document.getElementById('solarCanvas');
const ctx = canvas.getContext('2d');
const infoBox = document.getElementById('infoBox');
const music = document.getElementById('bgMusic');
const toggleBtn = document.getElementById('toggleMotion');
const speedBtn = document.getElementById('toggleSpeed');
const seasonBtn = document.getElementById('toggleSeason');

music.volume = 1.0;

function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

const stars = Array.from({length: 200}, () => ({
  x: Math.random() * canvas.width,
  y: Math.random() * canvas.height,
  radius: Math.random() * 1.5,
  alpha: Math.random()
}));

const sun = {
  x: canvas.width / 2,
  y: canvas.height / 2 - 80,
  radius: 20,
  color: 'yellow'
};

const planets = [
  { name: "Merkurius", desc: "Planet terkecil dan terdekat dari Matahari.", radius: 5, distance: 40, speed: 0.02, angle: 0, rot: 0, rotSpeed: 0.05, color: 'gray', image: "img/merkurius.jpg" },
  { name: "Venus", desc: "Planet kedua dari Matahari, memiliki atmosfer tebal.", radius: 6, distance: 70, speed: 0.015, angle: 0, rot: 0, rotSpeed: 0.03, color: 'orange', image: "img/venus.jpg" },
  { name: "Bumi", desc: "Satu-satunya planet yang diketahui memiliki kehidupan.", radius: 7, distance: 100, speed: 0.01, angle: 0, rot: 0, rotSpeed: 0.1, color: 'blue', image: "img/bumi.jpg" },
  { name: "Mars", desc: "Planet merah yang memiliki kemungkinan kehidupan masa lalu.", radius: 6, distance: 130, speed: 0.008, angle: 0, rot: 0, rotSpeed: 0.07, color: 'red', image: "img/mars.jpg" },
  { name: "Jupiter", desc: "Planet terbesar di Tata Surya.", radius: 10, distance: 180, speed: 0.005, angle: 0, rot: 0, rotSpeed: 0.03, color: 'orange', image: "img/jupiter.jpg" },
  { name: "Saturnus", desc: "Dikenal dengan cincin es yang indah.", radius: 9, distance: 230, speed: 0.004, angle: 0, rot: 0, rotSpeed: 0.025, color: 'beige', image: "img/saturnus.jpg" },
  { name: "Uranus", desc: "Planet es raksasa yang miring pada sisinya.", radius: 8, distance: 270, speed: 0.003, angle: 0, rot: 0, rotSpeed: 0.02, color: 'lightblue', image: "img/uranus.jpg" },
  { name: "Neptunus", desc: "Planet paling jauh dengan angin tercepat.", radius: 8, distance: 310, speed: 0.002, angle: 0, rot: 0, rotSpeed: 0.02, color: 'blue', image: "img/neptunus.jpg" }
];

let motionPaused = false;
let lightSpeed = false;
let seasonMode = false;
let seasonType = 'summer';

toggleBtn.onclick = () => {
  motionPaused = !motionPaused;
  toggleBtn.textContent = motionPaused ? "Lanjutkan Orbit" : "Pause Orbit";
};

speedBtn.onclick = () => {
  lightSpeed = !lightSpeed;
  speedBtn.textContent = "Kecepatan Cahaya: " + (lightSpeed ? "ON" : "OFF");
};

seasonBtn.onclick = () => {
  motionPaused = true;
  seasonMode = true;
  let angle = (seasonType === 'summer') ? 0 : Math.PI;
  const earth = planets.find(p => p.name === 'Bumi');
  const offset = angle - earth.angle;
  planets.forEach(p => p.angle += offset);
  seasonBtn.textContent = (seasonType === 'summer') ? "Musim Dingin" : "Musim Panas";
  seasonType = (seasonType === 'summer') ? 'winter' : 'summer';
};

canvas.addEventListener("click", (e) => {
  const rect = canvas.getBoundingClientRect();
  const mouseX = e.clientX - rect.left;
  const mouseY = e.clientY - rect.top;
  for (let planet of planets) {
    const x = sun.x + planet.distance * Math.cos(planet.angle);
    const y = sun.y + planet.distance * Math.sin(planet.angle);
    const dx = mouseX - x;
    const dy = mouseY - y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist < planet.radius + 5) {
      infoBox.style.display = 'block';
      infoBox.innerHTML = `<strong>${planet.name}</strong><br>${planet.desc}<img src="${planet.image}" alt="${planet.name}">`;
      return;
    }
  }
  infoBox.style.display = 'none';
});

function drawStars() {
  stars.forEach(s => {
    ctx.beginPath();
    ctx.arc(s.x, s.y, s.radius, 0, 2 * Math.PI);
    ctx.fillStyle = `rgba(255,255,255,${s.alpha})`;
    ctx.fill();
  });
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawStars();
  ctx.beginPath();
  ctx.arc(sun.x, sun.y, sun.radius, 0, Math.PI * 2);
  ctx.fillStyle = sun.color;
  ctx.fill();
  planets.forEach(planet => {
    if (!motionPaused) {
      planet.angle += lightSpeed ? planet.speed * 10 : planet.speed;
      planet.rot += planet.rotSpeed;
    }
    const x = sun.x + planet.distance * Math.cos(planet.angle);
    const y = sun.y + planet.distance * Math.sin(planet.angle);
    ctx.beginPath();
    ctx.arc(sun.x, sun.y, planet.distance, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(255,255,255,0.1)';
    ctx.stroke();
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(planet.rot);
    ctx.beginPath();
    ctx.arc(0, 0, planet.radius, 0, Math.PI * 2);
    ctx.fillStyle = planet.color;
    ctx.fill();
    ctx.restore();
  });
  requestAnimationFrame(draw);
}
draw();
